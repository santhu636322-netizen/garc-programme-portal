GARC Programme & Certification System — v4 demo
Changes:
• Professional portal title/branding.
• Uploaded institutional/partner logo strip displayed beside portal name/header.
• Admin event creation includes start and end time.
• Admin can edit published events (title/date/start/end/venue/description) through Manage published events.
• Certificate wording supports {NAME}, {EVENT}, {DATE}, {START}, {END}; certificate includes programme timing.
• Existing admin demo credentials: Drshenoy / Garc@636322.
Run: extract ZIP and open index.html in Chrome/Edge. Keep garc_partner_logos.jpeg in the same folder.
Note: local browser demo, not production-secure; data only in that browser.
